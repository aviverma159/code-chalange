﻿using System;

namespace CreditApp.Domain
{
    public class RequestModel
    {
        public int CreditAmount { get; set; }
        public int PeriodInMonth { get; set; }
        public int ExistingCredit { get; set; }
    }
}
