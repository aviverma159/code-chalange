﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreditApp.Domain
{
    public class ResponseModel
    {
        public string Decision { get;set;}
        public double InterestRate { get;set; }
    }
}
