using CreditApp.Domain;
using CreditApp.RestService.Controllers;
using System;
using Xunit;

namespace CreditApp.Test
{
    public class UnitTest1
    {
        [Fact]
        public void ValidateCredit()
        {
            var Controller = new ValidateCreditController();
            RequestModel requestModel = new RequestModel();
            var data = Controller.CheckCredit(requestModel);
            Assert.IsType<ResponseModel>(data);
        }
    }
}
