﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CreditApp.Domain;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CreditApp.RestService.Controllers
{
    [Route("api/[controller]")]
    public class ValidateCreditController : Controller
    {

        [HttpGet("CheckCredit")]
        public ResponseModel CheckCredit(RequestModel requestModel)
        {
            ResponseModel responseModel = new ResponseModel();
            if (requestModel.ExistingCredit < 2000 || requestModel.ExistingCredit > 69000)
            {
                responseModel.Decision = "No";
            }
            else
            {
                responseModel.Decision = "Yes";
            }
            responseModel.InterestRate = GetInterestRate(requestModel.CreditAmount);
            return responseModel;
        }

        public int GetInterestRate(int amount)
        {
            int rate = 0;
            if (amount < 20000)
            {
                rate = 3;
            }
            else if (amount > 20000 || amount < 390000)
            {
                rate = 4;
            }
            else if (amount > 40000 || amount < 590000)
            {
                rate = 5;
            }
            else if (amount > 60000)
            {
                rate = 6;
            }
            return rate;
        }

    }
}
